# Linux Network Troubleshooting Script

This repo will be dedicated to our in-class coding session. The script itself gathers network information and then uses that to do some basic packet captures and troubleshooting. Below is an example output of the finished script. This has been tested on Ubuntu 20.04 and Debian 10.  Thanks again to all the students that have helped develop this code! 


![alt text](http://gitlab.itsj.int/fmorehouse/linux-network-troubleshooting-script/raw/master/images/wf_scrn_1.PNG?raw=true)